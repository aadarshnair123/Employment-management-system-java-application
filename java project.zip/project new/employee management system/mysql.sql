create database employeemanagement;
use employeemanagement;
create table login(username varchar(20),password varchar(20));
insert into login values('aadarsh','12345678');
